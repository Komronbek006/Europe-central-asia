import { Link } from "react-router-dom";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { ShieldCheck } from "lucide-react";

interface ProductCardProps {
  id: string;
  name: string;
  slug: string;
  category: string;
  country: string;
  flag: string;
  moq: string;
  priceFrom: number;
  priceTo: number;
  currency: string;
  unit: string;
  supplier: string;
  supplierId: string;
  verified: boolean;
  image: string;
}

export function ProductCard({ name, slug, category, country, flag, moq, priceFrom, priceTo, currency, unit, supplier, verified, image }: ProductCardProps) {
  return (
    <Card className="group overflow-hidden border border-border hover:border-primary/30 transition-all hover:shadow-lg">
      <div className="aspect-[4/3] overflow-hidden bg-muted">
        <img
          src={image}
          alt={name}
          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
        />
      </div>
      <CardContent className="p-4">
        <div className="flex items-center justify-between mb-2">
          <Badge variant="secondary" className="text-xs">{category}</Badge>
          {verified && (
            <Badge variant="outline" className="text-xs text-primary border-primary/30 gap-1">
              <ShieldCheck size={12} /> Verified
            </Badge>
          )}
        </div>
        <h3 className="font-semibold text-sm mb-1 line-clamp-1">{name}</h3>
        <p className="text-xs text-muted-foreground mb-2">
          {flag} {country} · by {supplier}
        </p>
        <div className="flex items-baseline gap-1 mb-1">
          <span className="text-sm font-bold text-primary">
            ${priceFrom.toFixed(2)} – ${priceTo.toFixed(2)}
          </span>
          <span className="text-xs text-muted-foreground">/ {unit}</span>
        </div>
        <p className="text-xs text-muted-foreground mb-3">MOQ: {moq}</p>
        <div className="flex gap-2">
          <Button size="sm" variant="outline" className="flex-1 text-xs" asChild>
            <Link to={`/product/${slug}`}>View Details</Link>
          </Button>
          <Button size="sm" className="flex-1 text-xs">Contact</Button>
        </div>
      </CardContent>
    </Card>
  );
}
