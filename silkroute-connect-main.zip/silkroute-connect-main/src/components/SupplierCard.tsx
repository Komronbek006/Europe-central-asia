import { Link } from "react-router-dom";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { ShieldCheck, Package } from "lucide-react";

interface SupplierCardProps {
  id: string;
  name: string;
  slug: string;
  country: string;
  flag: string;
  categories: string[];
  productCount: number;
  verified: boolean;
}

export function SupplierCard({ name, slug, country, flag, categories, productCount, verified }: SupplierCardProps) {
  const initials = name.split(" ").map(w => w[0]).join("").slice(0, 2);

  return (
    <Card className="hover:border-primary/30 transition-all hover:shadow-md">
      <CardContent className="p-6">
        <div className="flex items-start gap-4">
          <Avatar className="h-14 w-14 bg-primary/10 text-primary">
            <AvatarFallback className="bg-primary/10 text-primary font-bold">{initials}</AvatarFallback>
          </Avatar>
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2 mb-1">
              <h3 className="font-semibold text-sm truncate">{name}</h3>
              {verified && <ShieldCheck size={16} className="text-primary flex-shrink-0" />}
            </div>
            <p className="text-xs text-muted-foreground mb-2">{flag} {country}</p>
            <div className="flex flex-wrap gap-1 mb-3">
              {categories.map(cat => (
                <Badge key={cat} variant="secondary" className="text-xs">{cat}</Badge>
              ))}
            </div>
            <div className="flex items-center justify-between">
              <span className="text-xs text-muted-foreground flex items-center gap-1">
                <Package size={12} /> {productCount} products
              </span>
              <Button size="sm" variant="outline" className="text-xs" asChild>
                <Link to={`/supplier/${slug}`}>View Profile</Link>
              </Button>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
