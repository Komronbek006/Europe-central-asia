import { Link } from "react-router-dom";
import { Linkedin, MessageCircle, Mail } from "lucide-react";
import { Separator } from "@/components/ui/separator";

export function Footer() {
  return (
    <footer className="bg-foreground text-background">
      <div className="container-narrow section-padding">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-10">
          {/* Brand */}
          <div>
            <div className="flex items-center gap-2 mb-4">
              <span className="text-2xl">🛤️</span>
              <span className="text-lg font-bold">SilkRoute Trade</span>
            </div>
            <p className="text-sm text-background/60 leading-relaxed">
              Connecting Central Asian suppliers with European wholesale buyers.
              Verified trade, simplified.
            </p>
          </div>

          {/* Platform */}
          <div>
            <h4 className="text-sm font-semibold mb-4 text-secondary">Platform</h4>
            <ul className="space-y-2.5 text-sm text-background/60">
              <li><Link to="/products" className="hover:text-background transition-colors">Products</Link></li>
              <li><Link to="/suppliers" className="hover:text-background transition-colors">Suppliers</Link></li>
              <li><Link to="/for-buyers" className="hover:text-background transition-colors">For Buyers</Link></li>
              <li><Link to="/for-suppliers" className="hover:text-background transition-colors">For Suppliers</Link></li>
            </ul>
          </div>

          {/* Company */}
          <div>
            <h4 className="text-sm font-semibold mb-4 text-secondary">Company</h4>
            <ul className="space-y-2.5 text-sm text-background/60">
              <li><Link to="/blog" className="hover:text-background transition-colors">Blog</Link></li>
              <li><Link to="/contact" className="hover:text-background transition-colors">Contact</Link></li>
              <li><a href="#" className="hover:text-background transition-colors">Privacy Policy</a></li>
              <li><a href="#" className="hover:text-background transition-colors">Terms of Service</a></li>
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h4 className="text-sm font-semibold mb-4 text-secondary">Contact</h4>
            <ul className="space-y-2.5 text-sm text-background/60">
              <li className="flex items-center gap-2">
                <Mail size={14} /> info@silkroutetrade.com
              </li>
            </ul>
            <div className="flex gap-3 mt-4">
              <a href="#" className="w-9 h-9 rounded-full bg-background/10 flex items-center justify-center hover:bg-background/20 transition-colors">
                <Linkedin size={16} />
              </a>
              <a href="#" className="w-9 h-9 rounded-full bg-background/10 flex items-center justify-center hover:bg-background/20 transition-colors">
                <MessageCircle size={16} />
              </a>
            </div>
          </div>
        </div>

        <Separator className="my-8 bg-background/10" />

        <p className="text-center text-xs text-background/40">
          © {new Date().getFullYear()} SilkRoute Trade. All rights reserved.
        </p>
      </div>
    </footer>
  );
}
