import { useState } from "react";
import { Layout } from "@/components/layout/Layout";
import { SupplierCard } from "@/components/SupplierCard";
import { suppliers, categories } from "@/data/mock-data";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";

const countries = ["All", "Uzbekistan", "Kazakhstan", "Tajikistan", "Kyrgyzstan"];

const Suppliers = () => {
  const [country, setCountry] = useState("All");
  const [category, setCategory] = useState("All");
  const [verifiedOnly, setVerifiedOnly] = useState(false);

  const filtered = suppliers.filter(s => {
    if (country !== "All" && s.country !== country) return false;
    if (category !== "All" && !s.categories.includes(category)) return false;
    if (verifiedOnly && !s.verified) return false;
    return true;
  });

  return (
    <Layout>
      <div className="bg-surface border-b border-border">
        <div className="container-narrow py-8">
          <h1 className="text-3xl font-bold mb-2">Verified Suppliers</h1>
          <p className="text-muted-foreground">Browse trusted suppliers from Central Asia</p>
        </div>
      </div>
      <div className="container-narrow py-8">
        <div className="flex flex-wrap items-center gap-4 mb-8">
          <Select value={country} onValueChange={setCountry}>
            <SelectTrigger className="w-[180px]"><SelectValue /></SelectTrigger>
            <SelectContent>
              {countries.map(c => <SelectItem key={c} value={c}>{c}</SelectItem>)}
            </SelectContent>
          </Select>
          <Select value={category} onValueChange={setCategory}>
            <SelectTrigger className="w-[180px]"><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="All">All Categories</SelectItem>
              {categories.map(c => <SelectItem key={c.slug} value={c.name}>{c.name}</SelectItem>)}
            </SelectContent>
          </Select>
          <div className="flex items-center gap-2">
            <Switch id="verified-only" checked={verifiedOnly} onCheckedChange={setVerifiedOnly} />
            <Label htmlFor="verified-only" className="text-sm">Verified only</Label>
          </div>
        </div>
        <p className="text-sm text-muted-foreground mb-4">{filtered.length} suppliers found</p>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
          {filtered.map(s => <SupplierCard key={s.id} {...s} />)}
        </div>
      </div>
    </Layout>
  );
};

export default Suppliers;
