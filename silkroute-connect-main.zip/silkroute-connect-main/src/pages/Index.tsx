import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { ShieldCheck, Search, MessageSquare, Truck, Users, Globe, Award, Handshake, Star, ArrowRight, CheckCircle } from "lucide-react";
import { Layout } from "@/components/layout/Layout";
import { ProductCard } from "@/components/ProductCard";
import { categories, products, testimonials } from "@/data/mock-data";
import heroImage from "@/assets/hero-trade.jpg";
import { motion } from "framer-motion";

const stats = [
  { label: "Verified Suppliers", value: "500+" },
  { label: "Product Categories", value: "50+" },
  { label: "Export Countries", value: "30+" },
  { label: "Successful Deals", value: "2,000+" },
];

const fadeUp = {
  hidden: { opacity: 0, y: 20 },
  visible: (i: number) => ({ opacity: 1, y: 0, transition: { delay: i * 0.1, duration: 0.5 } }),
};

const Index = () => {
  return (
    <Layout>
      {/* Hero */}
      <section className="relative min-h-[600px] flex items-center">
        <div className="absolute inset-0">
          <img src={heroImage} alt="International trade" className="w-full h-full object-cover" />
          <div className="absolute inset-0 bg-foreground/70" />
        </div>
        <div className="container-narrow relative z-10 py-20">
          <motion.div initial={{ opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.7 }} className="max-w-2xl">
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-background mb-4 leading-tight">
              Connecting Central Asia with Europe
            </h1>
            <p className="text-lg text-background/80 mb-8 leading-relaxed">
              B2B wholesale marketplace for verified suppliers of{" "}
              <span className="text-secondary font-medium">Textiles</span> •{" "}
              <span className="text-secondary font-medium">Dried Fruits</span> •{" "}
              <span className="text-secondary font-medium">Nuts</span> •{" "}
              <span className="text-secondary font-medium">Agricultural Products</span>
            </p>
            <div className="flex flex-wrap gap-3 mb-10">
              <Button size="lg" asChild>
                <Link to="/products">Find Suppliers</Link>
              </Button>
              <Button size="lg" variant="outline" className="border-background/30 text-background hover:bg-background/10" asChild>
                <Link to="/for-suppliers">Become a Supplier</Link>
              </Button>
            </div>
            <div className="flex flex-wrap gap-6 text-sm text-background/70">
              <span className="flex items-center gap-1.5"><ShieldCheck size={16} className="text-secondary" /> 500+ Verified Suppliers</span>
              <span className="flex items-center gap-1.5"><Globe size={16} className="text-secondary" /> 30+ Countries</span>
              <span className="flex items-center gap-1.5"><Award size={16} className="text-secondary" /> ISO Certified Partners</span>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Categories */}
      <section className="section-padding">
        <div className="container-narrow">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold mb-3">Browse by Category</h2>
            <p className="text-muted-foreground">Explore products from Central Asian suppliers</p>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
            {categories.map((cat, i) => (
              <motion.div key={cat.slug} custom={i} initial="hidden" whileInView="visible" viewport={{ once: true }} variants={fadeUp}>
                <Link to={`/products?category=${cat.slug}`}>
                  <Card className="text-center hover:border-primary/40 hover:shadow-md transition-all cursor-pointer group">
                    <CardContent className="p-6">
                      <span className="text-4xl block mb-3 group-hover:scale-110 transition-transform">{cat.icon}</span>
                      <h3 className="font-semibold text-sm mb-1">{cat.name}</h3>
                      <p className="text-xs text-muted-foreground">{cat.count} products</p>
                    </CardContent>
                  </Card>
                </Link>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Featured Products */}
      <section className="section-padding bg-surface">
        <div className="container-narrow">
          <div className="flex items-center justify-between mb-10">
            <div>
              <h2 className="text-3xl font-bold mb-2">Featured Products</h2>
              <p className="text-muted-foreground">Hand-picked products from top suppliers</p>
            </div>
            <Button variant="outline" asChild className="hidden md:flex">
              <Link to="/products">View All <ArrowRight size={16} className="ml-1" /></Link>
            </Button>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
            {products.slice(0, 8).map((product) => (
              <ProductCard key={product.id} {...product} />
            ))}
          </div>
          <div className="md:hidden text-center mt-8">
            <Button variant="outline" asChild>
              <Link to="/products">View All Products</Link>
            </Button>
          </div>
        </div>
      </section>

      {/* How It Works */}
      <section className="section-padding">
        <div className="container-narrow">
          <div className="text-center mb-14">
            <h2 className="text-3xl font-bold mb-3">How It Works</h2>
            <p className="text-muted-foreground">Three simple steps to start trading</p>
          </div>
          <div className="grid md:grid-cols-3 gap-8">
            {[
              { icon: Search, title: "Browse & Find", desc: "Search verified suppliers from Central Asia across 50+ product categories." },
              { icon: MessageSquare, title: "Connect & Negotiate", desc: "Contact suppliers directly, discuss pricing, terms, and sample orders." },
              { icon: Truck, title: "Ship to Europe", desc: "Get logistics support and export documentation assistance." },
            ].map((step, i) => (
              <motion.div key={step.title} custom={i} initial="hidden" whileInView="visible" viewport={{ once: true }} variants={fadeUp} className="text-center relative">
                <div className="w-16 h-16 rounded-full bg-primary/10 flex items-center justify-center mx-auto mb-5">
                  <step.icon size={28} className="text-primary" />
                </div>
                <div className="absolute top-8 left-[60%] right-0 h-px bg-border hidden md:block last:hidden" />
                <h3 className="font-semibold text-lg mb-2">{step.title}</h3>
                <p className="text-sm text-muted-foreground leading-relaxed">{step.desc}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Benefits */}
      <section className="section-padding bg-surface">
        <div className="container-narrow">
          <div className="text-center mb-14">
            <h2 className="text-3xl font-bold mb-3">Why SilkRoute Trade?</h2>
          </div>
          <div className="grid md:grid-cols-2 gap-8">
            <Card className="border-primary/20">
              <CardContent className="p-8">
                <Badge className="mb-4">For Buyers</Badge>
                <ul className="space-y-4">
                  {["Verified and vetted suppliers", "Factory-direct wholesale prices", "Export documentation support", "Quality guarantee program"].map(b => (
                    <li key={b} className="flex items-start gap-3 text-sm"><CheckCircle size={18} className="text-primary flex-shrink-0 mt-0.5" /> {b}</li>
                  ))}
                </ul>
              </CardContent>
            </Card>
            <Card className="border-secondary/30">
              <CardContent className="p-8">
                <Badge variant="secondary" className="mb-4">For Suppliers</Badge>
                <ul className="space-y-4">
                  {["Access to European market", "Marketing and visibility support", "Connect with new export clients", "Logistics and shipping assistance"].map(b => (
                    <li key={b} className="flex items-start gap-3 text-sm"><CheckCircle size={18} className="text-secondary flex-shrink-0 mt-0.5" /> {b}</li>
                  ))}
                </ul>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="section-padding">
        <div className="container-narrow">
          <div className="text-center mb-14">
            <h2 className="text-3xl font-bold mb-3">What Our Partners Say</h2>
          </div>
          <div className="grid md:grid-cols-3 gap-6">
            {testimonials.map((t, i) => (
              <motion.div key={t.name} custom={i} initial="hidden" whileInView="visible" viewport={{ once: true }} variants={fadeUp}>
                <Card>
                  <CardContent className="p-6">
                    <div className="flex gap-0.5 mb-4">
                      {Array.from({ length: t.rating }).map((_, j) => (
                        <Star key={j} size={16} className="fill-secondary text-secondary" />
                      ))}
                    </div>
                    <p className="text-sm text-muted-foreground mb-4 italic leading-relaxed">"{t.quote}"</p>
                    <Separator className="mb-4" />
                    <p className="font-semibold text-sm">{t.name}</p>
                    <p className="text-xs text-muted-foreground">{t.company} · {t.flag} {t.country}</p>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Stats Bar */}
      <section className="py-16 bg-primary">
        <div className="container-narrow">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 text-center">
            {stats.map((stat) => (
              <div key={stat.label}>
                <div className="text-3xl md:text-4xl font-bold text-primary-foreground mb-1">{stat.value}</div>
                <p className="text-sm text-primary-foreground/70">{stat.label}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="section-padding">
        <div className="container-narrow text-center">
          <h2 className="text-3xl font-bold mb-4">Ready to Start Trading?</h2>
          <p className="text-muted-foreground mb-8 max-w-lg mx-auto">
            Join hundreds of businesses already trading on SilkRoute Trade.
          </p>
          <div className="flex flex-wrap justify-center gap-3">
            <Button size="lg" asChild><Link to="/register?type=buyer">Register as Buyer</Link></Button>
            <Button size="lg" variant="outline" asChild><Link to="/register?type=supplier">Register as Supplier</Link></Button>
          </div>
        </div>
      </section>
    </Layout>
  );
};

export default Index;
