import { Layout } from "@/components/layout/Layout";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Mail, Phone, MessageCircle, MapPin } from "lucide-react";

const Contact = () => {
  return (
    <Layout>
      <div className="bg-surface border-b border-border">
        <div className="container-narrow py-8">
          <h1 className="text-3xl font-bold mb-2">Contact Us</h1>
          <p className="text-muted-foreground">Get in touch with our team</p>
        </div>
      </div>
      <div className="container-narrow py-12">
        <div className="grid lg:grid-cols-2 gap-12">
          {/* Form */}
          <div>
            <h2 className="text-xl font-semibold mb-6">Send us a message</h2>
            <form className="space-y-4" onSubmit={e => e.preventDefault()}>
              <div className="grid sm:grid-cols-2 gap-4">
                <div><Label>Name</Label><Input placeholder="Your name" /></div>
                <div><Label>Company</Label><Input placeholder="Company name" /></div>
              </div>
              <div><Label>Email</Label><Input type="email" placeholder="email@company.com" /></div>
              <div><Label>Subject</Label>
                <Select><SelectTrigger><SelectValue placeholder="Select subject" /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="general">General Inquiry</SelectItem>
                    <SelectItem value="buyer">Buyer Support</SelectItem>
                    <SelectItem value="supplier">Supplier Support</SelectItem>
                    <SelectItem value="partnership">Partnership</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div><Label>Message</Label><Textarea placeholder="How can we help?" rows={5} /></div>
              <Button size="lg">Send Message</Button>
            </form>
          </div>

          {/* Info */}
          <div className="space-y-6">
            <h2 className="text-xl font-semibold mb-6">Our Offices</h2>
            <Card><CardContent className="p-5">
              <h3 className="font-semibold mb-3 flex items-center gap-2"><MapPin size={16} className="text-primary" /> Germany HQ</h3>
              <p className="text-sm text-muted-foreground leading-relaxed">SilkRoute Trade GmbH<br />Friedrichstraße 123<br />10117 Berlin, Germany</p>
            </CardContent></Card>
            <Card><CardContent className="p-5">
              <h3 className="font-semibold mb-3 flex items-center gap-2"><MapPin size={16} className="text-primary" /> Uzbekistan Office</h3>
              <p className="text-sm text-muted-foreground leading-relaxed">SilkRoute Trade LLC<br />Amir Temur Avenue 45<br />100084 Tashkent, Uzbekistan</p>
            </CardContent></Card>
            <div className="space-y-3">
              <div className="flex items-center gap-3 text-sm"><Mail size={16} className="text-primary" /> info@silkroutetrade.com</div>
              <div className="flex items-center gap-3 text-sm"><Phone size={16} className="text-primary" /> +49 30 1234 5678</div>
              <div className="flex items-center gap-3 text-sm"><MessageCircle size={16} className="text-primary" /> WhatsApp: +998 90 123 4567</div>
            </div>
            {/* Map placeholder */}
            <div className="rounded-lg bg-muted h-48 flex items-center justify-center text-sm text-muted-foreground">
              Map placeholder
            </div>
          </div>
        </div>
      </div>
    </Layout>
  );
};

export default Contact;
