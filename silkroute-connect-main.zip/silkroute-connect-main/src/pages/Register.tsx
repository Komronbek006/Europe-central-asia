import { useState } from "react";
import { Link, useSearchParams, useNavigate } from "react-router-dom";
import { Layout } from "@/components/layout/Layout";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { ShoppingCart, Store } from "lucide-react";
import { useAuth } from "@/contexts/AuthContext";
import { useToast } from "@/hooks/use-toast";

const countries = ["Uzbekistan", "Kazakhstan", "Tajikistan", "Kyrgyzstan", "Turkmenistan", "Germany", "Poland", "France", "Netherlands", "United Kingdom", "Italy", "Spain", "Other"];

const Register = () => {
  const [searchParams] = useSearchParams();
  const [type, setType] = useState<"buyer" | "supplier">(searchParams.get("type") === "supplier" ? "supplier" : "buyer");
  const [companyName, setCompanyName] = useState("");
  const [country, setCountry] = useState("");
  const [fullName, setFullName] = useState("");
  const [email, setEmail] = useState("");
  const [phone, setPhone] = useState("");
  const [password, setPassword] = useState("");
  const [agreed, setAgreed] = useState(false);
  const [loading, setLoading] = useState(false);
  const { signUp } = useAuth();
  const navigate = useNavigate();
  const { toast } = useToast();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!agreed) {
      toast({ title: "Please agree to the terms", variant: "destructive" });
      return;
    }
    setLoading(true);
    const { error } = await signUp(email, password, {
      type,
      company_name: companyName,
      country,
      full_name: fullName,
      phone,
    });
    setLoading(false);
    if (error) {
      toast({ title: "Registration failed", description: error.message, variant: "destructive" });
    } else {
      toast({ title: "Account created!", description: "Please check your email to confirm your account." });
      navigate("/login");
    }
  };

  return (
    <Layout>
      <div className="container-narrow py-12">
        <div className="max-w-md mx-auto">
          <h1 className="text-3xl font-bold text-center mb-2">Create Account</h1>
          <p className="text-center text-muted-foreground mb-8">Join SilkRoute Trade today</p>

          {/* Type Toggle */}
          <div className="grid grid-cols-2 gap-3 mb-8">
            {[
              { value: "buyer" as const, icon: ShoppingCart, label: "I'm a Buyer" },
              { value: "supplier" as const, icon: Store, label: "I'm a Supplier" },
            ].map(option => (
              <Card
                key={option.value}
                className={`cursor-pointer transition-all ${type === option.value ? "border-primary bg-accent" : "hover:border-primary/30"}`}
                onClick={() => setType(option.value)}
              >
                <CardContent className="p-4 text-center">
                  <option.icon size={24} className={`mx-auto mb-2 ${type === option.value ? "text-primary" : "text-muted-foreground"}`} />
                  <p className="text-sm font-medium">{option.label}</p>
                </CardContent>
              </Card>
            ))}
          </div>

          <form className="space-y-4" onSubmit={handleSubmit}>
            <div><Label>Company Name</Label><Input placeholder="Your company name" value={companyName} onChange={e => setCompanyName(e.target.value)} required /></div>
            <div><Label>Country</Label>
              <Select value={country} onValueChange={setCountry}>
                <SelectTrigger><SelectValue placeholder="Select country" /></SelectTrigger>
                <SelectContent>{countries.map(c => <SelectItem key={c} value={c}>{c}</SelectItem>)}</SelectContent>
              </Select>
            </div>
            <div><Label>Full Name</Label><Input placeholder="Your full name" value={fullName} onChange={e => setFullName(e.target.value)} required /></div>
            <div><Label>Email</Label><Input type="email" placeholder="email@company.com" value={email} onChange={e => setEmail(e.target.value)} required /></div>
            <div><Label>Phone</Label><Input placeholder="+998 90 123 4567" value={phone} onChange={e => setPhone(e.target.value)} /></div>
            <div><Label>Password</Label><Input type="password" placeholder="Create a password" value={password} onChange={e => setPassword(e.target.value)} required minLength={6} /></div>
            <label className="flex items-start gap-2 cursor-pointer">
              <Checkbox className="mt-0.5" checked={agreed} onCheckedChange={(v) => setAgreed(v === true)} />
              <span className="text-xs text-muted-foreground">I agree to the Terms of Service and Privacy Policy</span>
            </label>
            <Button className="w-full" size="lg" disabled={loading}>
              {loading ? "Creating account..." : "Create Account"}
            </Button>
          </form>

          <p className="text-center text-sm text-muted-foreground mt-6">
            Already have an account? <Link to="/login" className="text-primary hover:underline">Login</Link>
          </p>
        </div>
      </div>
    </Layout>
  );
};

export default Register;
