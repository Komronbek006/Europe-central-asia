import { useEffect, useState } from "react";
import { Layout } from "@/components/layout/Layout";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Package, Eye, MessageSquare, Plus, Edit, Trash2, Loader2 } from "lucide-react";
import { Link } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { toast } from "sonner";

interface Product {
  id: string;
  name: string;
  category: string;
  moq: number;
  moq_unit: string;
  is_published: boolean;
  slug: string;
}

interface Inquiry {
  id: string;
  message: string;
  status: string;
  created_at: string;
  buyer: { company_name: string } | null;
  product: { name: string } | null;
}

const Dashboard = () => {
  const { profile } = useAuth();
  const [products, setProducts] = useState<Product[]>([]);
  const [inquiries, setInquiries] = useState<Inquiry[]>([]);
  const [profileViews, setProfileViews] = useState(0);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!profile) return;
    const load = async () => {
      setLoading(true);
      if (profile.type === "supplier") {
        const [prodRes, inqRes] = await Promise.all([
          supabase
            .from("products")
            .select("id, name, category, moq, moq_unit, is_published, slug")
            .eq("supplier_id", profile.id)
            .order("created_at", { ascending: false }),
          supabase
            .from("inquiries")
            .select("id, message, status, created_at, buyer:buyer_id(company_name), product:product_id(name)")
            .eq("supplier_id", profile.id)
            .order("created_at", { ascending: false }),
        ]);
        setProducts(prodRes.data ?? []);
        setInquiries((inqRes.data as unknown as Inquiry[]) ?? []);
        // Sum view_count across products as a proxy for profile views
        const viewRes = await supabase
          .from("products")
          .select("view_count")
          .eq("supplier_id", profile.id);
        setProfileViews(
          (viewRes.data ?? []).reduce((sum: number, p: { view_count: number }) => sum + (p.view_count || 0), 0)
        );
      } else {
        // buyer
        const inqRes = await supabase
          .from("inquiries")
          .select("id, message, status, created_at, buyer:buyer_id(company_name), product:product_id(name)")
          .eq("buyer_id", profile.id)
          .order("created_at", { ascending: false });
        setInquiries((inqRes.data as unknown as Inquiry[]) ?? []);
      }
      setLoading(false);
    };
    load();
  }, [profile]);

  const handleDelete = async (productId: string) => {
    const { error } = await supabase.from("products").delete().eq("id", productId);
    if (error) {
      toast.error("Failed to delete product");
    } else {
      setProducts((prev) => prev.filter((p) => p.id !== productId));
      toast.success("Product deleted");
    }
  };

  if (loading) {
    return (
      <Layout>
        <div className="flex items-center justify-center py-24">
          <Loader2 className="animate-spin text-primary" size={32} />
        </div>
      </Layout>
    );
  }

  const isSupplier = profile?.type === "supplier";

  return (
    <Layout>
      <div className="bg-surface border-b border-border">
        <div className="container-narrow py-8">
          <h1 className="text-3xl font-bold mb-1">Dashboard</h1>
          <p className="text-muted-foreground">Welcome back, {profile?.company_name}</p>
        </div>
      </div>

      <div className="container-narrow py-8">
        {isSupplier && (
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-8">
            {[
              { icon: Package, label: "Products", value: String(products.length) },
              { icon: MessageSquare, label: "Inquiries", value: String(inquiries.length) },
              { icon: Eye, label: "Product Views", value: String(profileViews) },
            ].map((s) => (
              <Card key={s.label}>
                <CardContent className="p-5 flex items-center gap-4">
                  <s.icon size={24} className="text-primary" />
                  <div>
                    <p className="text-2xl font-bold">{s.value}</p>
                    <p className="text-xs text-muted-foreground">{s.label}</p>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}

        <Tabs defaultValue={isSupplier ? "products" : "inquiries"}>
          <TabsList className="mb-6">
            {isSupplier && <TabsTrigger value="products">My Products</TabsTrigger>}
            <TabsTrigger value="inquiries">{isSupplier ? "Inquiries" : "My Inquiries"}</TabsTrigger>
          </TabsList>

          {isSupplier && (
            <TabsContent value="products">
              <div className="flex justify-between items-center mb-4">
                <h2 className="font-semibold">Your Products</h2>
                <Button size="sm" asChild>
                  <Link to="/dashboard/add-product">
                    <Plus size={14} className="mr-1" /> Add Product
                  </Link>
                </Button>
              </div>
              {products.length === 0 ? (
                <p className="text-muted-foreground text-sm py-8 text-center">No products yet. Add your first product!</p>
              ) : (
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Product</TableHead>
                      <TableHead>Category</TableHead>
                      <TableHead>MOQ</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead className="text-right">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {products.map((p) => (
                      <TableRow key={p.id}>
                        <TableCell className="font-medium">{p.name}</TableCell>
                        <TableCell>{p.category}</TableCell>
                        <TableCell>{p.moq} {p.moq_unit}</TableCell>
                        <TableCell>
                          <Badge variant={p.is_published ? "default" : "secondary"}>
                            {p.is_published ? "Published" : "Draft"}
                          </Badge>
                        </TableCell>
                        <TableCell className="text-right">
                          <Button variant="ghost" size="icon"><Edit size={14} /></Button>
                          <Button variant="ghost" size="icon" onClick={() => handleDelete(p.id)}>
                            <Trash2 size={14} />
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              )}
            </TabsContent>
          )}

          <TabsContent value="inquiries">
            {inquiries.length === 0 ? (
              <p className="text-muted-foreground text-sm py-8 text-center">No inquiries yet.</p>
            ) : (
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>{isSupplier ? "Buyer" : "Product"}</TableHead>
                    <TableHead>Message</TableHead>
                    <TableHead>Date</TableHead>
                    <TableHead>Status</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {inquiries.map((i) => (
                    <TableRow key={i.id}>
                      <TableCell className="font-medium">
                        {isSupplier ? (i.buyer?.company_name ?? "—") : (i.product?.name ?? "—")}
                      </TableCell>
                      <TableCell className="text-muted-foreground text-sm max-w-[250px] truncate">{i.message}</TableCell>
                      <TableCell className="text-sm">{new Date(i.created_at).toLocaleDateString()}</TableCell>
                      <TableCell>
                        <Badge variant={i.status === "pending" ? "secondary" : "default"}>{i.status}</Badge>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            )}
          </TabsContent>
        </Tabs>
      </div>
    </Layout>
  );
};

export default Dashboard;
