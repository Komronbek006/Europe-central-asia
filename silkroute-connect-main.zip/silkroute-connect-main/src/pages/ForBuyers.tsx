import { Link } from "react-router-dom";
import { Layout } from "@/components/layout/Layout";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { ShieldCheck, DollarSign, FileCheck, HeadphonesIcon, CheckCircle } from "lucide-react";
import { categories } from "@/data/mock-data";

const ForBuyers = () => {
  return (
    <Layout>
      {/* Hero */}
      <section className="bg-foreground py-20">
        <div className="container-narrow text-center">
          <h1 className="text-4xl md:text-5xl font-bold text-background mb-4">Source Directly from Central Asia</h1>
          <p className="text-lg text-background/70 max-w-xl mx-auto mb-8">
            Find verified suppliers, negotiate factory-direct prices, and import with confidence.
          </p>
          <Button size="lg" asChild>
            <Link to="/register?type=buyer">Register as Buyer</Link>
          </Button>
        </div>
      </section>

      {/* Benefits */}
      <section className="section-padding">
        <div className="container-narrow">
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {[
              { icon: ShieldCheck, title: "Verified Suppliers", desc: "Every supplier is vetted and verified for quality and reliability." },
              { icon: DollarSign, title: "Best Wholesale Prices", desc: "Factory-direct pricing with no middlemen or hidden fees." },
              { icon: FileCheck, title: "Safe Transactions", desc: "Trade assurance and secure payment options available." },
              { icon: HeadphonesIcon, title: "Dedicated Support", desc: "Multilingual support team to assist with your sourcing needs." },
            ].map(b => (
              <Card key={b.title}><CardContent className="p-6 text-center"><b.icon size={32} className="text-primary mx-auto mb-3" /><h3 className="font-semibold mb-2">{b.title}</h3><p className="text-sm text-muted-foreground">{b.desc}</p></CardContent></Card>
            ))}
          </div>
        </div>
      </section>

      {/* Categories */}
      <section className="section-padding bg-surface">
        <div className="container-narrow">
          <h2 className="text-3xl font-bold text-center mb-10">Featured Categories</h2>
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
            {categories.map(cat => (
              <Link key={cat.slug} to={`/products?category=${cat.slug}`}>
                <Card className="text-center hover:border-primary/40 transition-all"><CardContent className="p-6"><span className="text-3xl block mb-2">{cat.icon}</span><h3 className="text-sm font-medium">{cat.name}</h3></CardContent></Card>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="section-padding text-center">
        <div className="container-narrow">
          <h2 className="text-3xl font-bold mb-4">Start Sourcing Today</h2>
          <p className="text-muted-foreground mb-8 max-w-md mx-auto">Create a free account and start connecting with verified Central Asian suppliers.</p>
          <Button size="lg" asChild><Link to="/register?type=buyer">Register as Buyer</Link></Button>
        </div>
      </section>
    </Layout>
  );
};

export default ForBuyers;
