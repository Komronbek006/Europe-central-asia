import { Link } from "react-router-dom";
import { Layout } from "@/components/layout/Layout";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { blogPosts } from "@/data/mock-data";
import { CalendarDays, ArrowRight } from "lucide-react";

const Blog = () => {
  const featured = blogPosts.find(p => p.featured);
  const rest = blogPosts.filter(p => !p.featured);

  return (
    <Layout>
      <div className="bg-surface border-b border-border">
        <div className="container-narrow py-8">
          <h1 className="text-3xl font-bold mb-2">Blog & Insights</h1>
          <p className="text-muted-foreground">Trade insights, market trends, and export guides</p>
        </div>
      </div>
      <div className="container-narrow py-8">
        {/* Featured */}
        {featured && (
          <Card className="mb-8 overflow-hidden">
            <div className="grid md:grid-cols-2">
              <img src={featured.coverImage} alt={featured.title} className="w-full h-64 md:h-full object-cover" />
              <CardContent className="p-8 flex flex-col justify-center">
                <Badge variant="secondary" className="w-fit mb-3">{featured.category}</Badge>
                <h2 className="text-2xl font-bold mb-3">{featured.title}</h2>
                <p className="text-sm text-muted-foreground mb-4 leading-relaxed">{featured.excerpt}</p>
                <div className="flex items-center gap-2 text-xs text-muted-foreground mb-4">
                  <CalendarDays size={12} /> {featured.publishedAt}
                </div>
                <Link to={`/blog/${featured.slug}`} className="text-primary text-sm font-medium inline-flex items-center gap-1 hover:underline">
                  Read More <ArrowRight size={14} />
                </Link>
              </CardContent>
            </div>
          </Card>
        )}

        {/* Grid */}
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {rest.map(post => (
            <Card key={post.id} className="overflow-hidden hover:shadow-md transition-shadow">
              <img src={post.coverImage} alt={post.title} className="w-full h-48 object-cover" />
              <CardContent className="p-5">
                <Badge variant="secondary" className="mb-2">{post.category}</Badge>
                <h3 className="font-semibold mb-2 line-clamp-2">{post.title}</h3>
                <p className="text-sm text-muted-foreground mb-3 line-clamp-2">{post.excerpt}</p>
                <div className="flex items-center justify-between">
                  <span className="text-xs text-muted-foreground flex items-center gap-1"><CalendarDays size={12} /> {post.publishedAt}</span>
                  <Link to={`/blog/${post.slug}`} className="text-primary text-xs font-medium hover:underline">Read More</Link>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </Layout>
  );
};

export default Blog;
