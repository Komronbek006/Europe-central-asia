import { Link } from "react-router-dom";
import { Layout } from "@/components/layout/Layout";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Users, Globe, Truck, BarChart3, CheckCircle } from "lucide-react";

const ForSuppliers = () => {
  return (
    <Layout>
      {/* Hero */}
      <section className="bg-primary py-20">
        <div className="container-narrow text-center">
          <h1 className="text-4xl md:text-5xl font-bold text-primary-foreground mb-4">Sell to Europe. Start Today.</h1>
          <p className="text-lg text-primary-foreground/80 max-w-xl mx-auto mb-8">
            List your products, connect with European wholesale buyers, and grow your export business.
          </p>
          <Button size="lg" variant="secondary" asChild>
            <Link to="/register?type=supplier">Register as Supplier</Link>
          </Button>
        </div>
      </section>

      {/* Benefits */}
      <section className="section-padding">
        <div className="container-narrow">
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {[
              { icon: Users, title: "50M+ European Buyers", desc: "Access to the largest consumer market in the world." },
              { icon: Globe, title: "Free Listing", desc: "List your products at no cost and start receiving inquiries." },
              { icon: Truck, title: "Export Support", desc: "Documentation and logistics assistance included." },
              { icon: BarChart3, title: "Marketing Tools", desc: "Featured listings, analytics, and visibility boost." },
            ].map(b => (
              <Card key={b.title}><CardContent className="p-6 text-center"><b.icon size={32} className="text-primary mx-auto mb-3" /><h3 className="font-semibold mb-2">{b.title}</h3><p className="text-sm text-muted-foreground">{b.desc}</p></CardContent></Card>
            ))}
          </div>
        </div>
      </section>

      {/* How to Register */}
      <section className="section-padding bg-surface">
        <div className="container-narrow text-center">
          <h2 className="text-3xl font-bold mb-12">Get Started in 3 Steps</h2>
          <div className="grid md:grid-cols-3 gap-8">
            {[
              { step: "1", title: "Create Account", desc: "Register with your company details and verify your identity." },
              { step: "2", title: "Add Products", desc: "Upload product photos, set pricing and MOQ details." },
              { step: "3", title: "Receive Inquiries", desc: "Start getting buyer inquiries from across Europe." },
            ].map(s => (
              <div key={s.step}>
                <div className="w-12 h-12 rounded-full bg-primary text-primary-foreground font-bold text-xl flex items-center justify-center mx-auto mb-4">{s.step}</div>
                <h3 className="font-semibold mb-2">{s.title}</h3>
                <p className="text-sm text-muted-foreground">{s.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Pricing */}
      <section className="section-padding">
        <div className="container-narrow">
          <h2 className="text-3xl font-bold text-center mb-12">Pricing Plans</h2>
          <div className="grid md:grid-cols-3 gap-6 max-w-4xl mx-auto">
            {[
              { name: "Free", price: "$0", features: ["5 product listings", "Basic profile", "Email support"], popular: false },
              { name: "Professional", price: "$99/mo", features: ["Unlimited listings", "Featured placement", "Analytics dashboard", "Priority support"], popular: true },
              { name: "Enterprise", price: "Custom", features: ["Everything in Pro", "Dedicated account manager", "Custom branding", "API access"], popular: false },
            ].map(plan => (
              <Card key={plan.name} className={plan.popular ? "border-primary shadow-lg relative" : ""}>
                {plan.popular && <Badge className="absolute -top-3 left-1/2 -translate-x-1/2">Most Popular</Badge>}
                <CardContent className="p-6">
                  <h3 className="font-bold text-lg mb-1">{plan.name}</h3>
                  <p className="text-3xl font-bold text-primary mb-6">{plan.price}</p>
                  <ul className="space-y-3 mb-6">
                    {plan.features.map(f => (
                      <li key={f} className="flex items-center gap-2 text-sm"><CheckCircle size={16} className="text-primary" /> {f}</li>
                    ))}
                  </ul>
                  <Button className="w-full" variant={plan.popular ? "default" : "outline"} asChild>
                    <Link to="/register?type=supplier">Get Started</Link>
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>
    </Layout>
  );
};

export default ForSuppliers;
