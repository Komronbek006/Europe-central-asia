import { useParams, Link } from "react-router-dom";
import { Layout } from "@/components/layout/Layout";
import { suppliers, products } from "@/data/mock-data";
import { ProductCard } from "@/components/ProductCard";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { ShieldCheck, Globe, Factory, Calendar, Award, MessageCircle } from "lucide-react";

const SupplierProfile = () => {
  const { slug } = useParams();
  const supplier = suppliers.find(s => s.slug === slug);

  if (!supplier) return <Layout><div className="container-narrow py-20 text-center"><h1 className="text-2xl font-bold">Supplier not found</h1><Link to="/suppliers" className="text-primary mt-4 inline-block">← Back to suppliers</Link></div></Layout>;

  const supplierProducts = products.filter(p => p.supplierId === supplier.id);
  const initials = supplier.name.split(" ").map(w => w[0]).join("").slice(0, 2);

  return (
    <Layout>
      <div className="bg-surface border-b border-border">
        <div className="container-narrow py-8">
          <div className="flex items-center gap-5">
            <Avatar className="h-20 w-20 text-2xl bg-primary/10 text-primary">
              <AvatarFallback className="bg-primary/10 text-primary font-bold text-2xl">{initials}</AvatarFallback>
            </Avatar>
            <div>
              <div className="flex items-center gap-2 mb-1">
                <h1 className="text-2xl font-bold">{supplier.name}</h1>
                {supplier.verified && <Badge className="gap-1"><ShieldCheck size={12} /> Verified</Badge>}
              </div>
              <p className="text-muted-foreground">{supplier.flag} {supplier.country} · Member since {supplier.memberSince}</p>
            </div>
          </div>
        </div>
      </div>

      <div className="container-narrow py-8">
        <Tabs defaultValue="products">
          <TabsList className="mb-8">
            <TabsTrigger value="products">Products ({supplierProducts.length})</TabsTrigger>
            <TabsTrigger value="about">About</TabsTrigger>
            <TabsTrigger value="certificates">Certificates</TabsTrigger>
            <TabsTrigger value="contact">Contact</TabsTrigger>
          </TabsList>

          <TabsContent value="products">
            {supplierProducts.length > 0 ? (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
                {supplierProducts.map(p => <ProductCard key={p.id} {...p} />)}
              </div>
            ) : (
              <p className="text-muted-foreground py-10 text-center">No products listed yet.</p>
            )}
          </TabsContent>

          <TabsContent value="about">
            <div className="max-w-2xl space-y-6">
              <p className="text-muted-foreground leading-relaxed">{supplier.description}</p>
              <div className="grid sm:grid-cols-2 gap-4">
                <Card><CardContent className="p-4 flex items-center gap-3"><Factory size={20} className="text-primary" /><div><p className="text-xs text-muted-foreground">Production Capacity</p><p className="font-semibold text-sm">{supplier.capacity}</p></div></CardContent></Card>
                <Card><CardContent className="p-4 flex items-center gap-3"><Globe size={20} className="text-primary" /><div><p className="text-xs text-muted-foreground">Export Countries</p><p className="font-semibold text-sm">{supplier.exportCountries.join(", ")}</p></div></CardContent></Card>
              </div>
            </div>
          </TabsContent>

          <TabsContent value="certificates">
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
              {supplier.certificates.map(cert => (
                <Card key={cert}><CardContent className="p-6 text-center"><Award size={28} className="text-secondary mx-auto mb-2" /><p className="font-semibold text-sm">{cert}</p></CardContent></Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="contact">
            <div className="max-w-md space-y-4">
              <Input placeholder="Your Name" />
              <Input placeholder="Company Name" />
              <Input placeholder="Email" type="email" />
              <Textarea placeholder="Your message..." rows={4} />
              <div className="flex gap-3">
                <Button className="flex-1">Send Message</Button>
                <Button variant="outline" className="gap-2"><MessageCircle size={16} /> WhatsApp</Button>
              </div>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </Layout>
  );
};

export default SupplierProfile;
