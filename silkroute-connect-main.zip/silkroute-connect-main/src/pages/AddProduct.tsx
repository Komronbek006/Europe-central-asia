import { useState } from "react";
import { Layout } from "@/components/layout/Layout";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent } from "@/components/ui/card";
import { Switch } from "@/components/ui/switch";
import { categories } from "@/data/mock-data";
import { Upload, ArrowLeft, ArrowRight, Loader2 } from "lucide-react";
import { Link, useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { toast } from "sonner";

const steps = ["Basic Info", "Details", "Photos", "Contact Preferences"];

const AddProduct = () => {
  const [step, setStep] = useState(0);
  const [saving, setSaving] = useState(false);
  const { profile } = useAuth();
  const navigate = useNavigate();

  const [form, setForm] = useState({
    category: "",
    name: "",
    country_of_origin: "",
    description: "",
    moq: "",
    moq_unit: "kg",
    price_from: "",
    price_to: "",
    packaging: "",
    shelf_life: "",
  });

  const set = (key: string, value: string) => setForm((f) => ({ ...f, [key]: value }));

  const handlePublish = async () => {
    if (!profile) return;
    setSaving(true);
    const slug = form.name.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/(^-|-$)/g, "") + "-" + Date.now();
    const { error } = await supabase.from("products").insert({
      supplier_id: profile.id,
      name: form.name,
      slug,
      category: form.category,
      country_of_origin: form.country_of_origin || "Uzbekistan",
      description: form.description || null,
      moq: parseInt(form.moq) || 100,
      moq_unit: form.moq_unit,
      price_from: form.price_from ? parseFloat(form.price_from) : null,
      price_to: form.price_to ? parseFloat(form.price_to) : null,
      packaging: form.packaging || null,
      shelf_life: form.shelf_life || null,
      is_published: true,
    });
    setSaving(false);
    if (error) {
      toast.error("Failed to add product: " + error.message);
    } else {
      toast.success("Product published!");
      navigate("/dashboard");
    }
  };

  return (
    <Layout>
      <div className="container-narrow py-8">
        <Link to="/dashboard" className="text-sm text-muted-foreground hover:text-foreground inline-flex items-center gap-1 mb-6">
          <ArrowLeft size={14} /> Back to Dashboard
        </Link>
        <h1 className="text-3xl font-bold mb-8">Add New Product</h1>

        <div className="flex items-center gap-2 mb-8">
          {steps.map((s, i) => (
            <div key={s} className="flex items-center gap-2">
              <div className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-medium ${i <= step ? "bg-primary text-primary-foreground" : "bg-muted text-muted-foreground"}`}>
                {i + 1}
              </div>
              <span className={`text-sm hidden sm:inline ${i <= step ? "text-foreground" : "text-muted-foreground"}`}>{s}</span>
              {i < steps.length - 1 && <div className="w-8 h-px bg-border" />}
            </div>
          ))}
        </div>

        <Card className="max-w-2xl">
          <CardContent className="p-6">
            {step === 0 && (
              <div className="space-y-4">
                <div>
                  <Label>Category</Label>
                  <Select value={form.category} onValueChange={(v) => set("category", v)}>
                    <SelectTrigger><SelectValue placeholder="Select category" /></SelectTrigger>
                    <SelectContent>{categories.map((c) => <SelectItem key={c.slug} value={c.slug}>{c.icon} {c.name}</SelectItem>)}</SelectContent>
                  </Select>
                </div>
                <div><Label>Product Name</Label><Input value={form.name} onChange={(e) => set("name", e.target.value)} placeholder="e.g. Premium Dried Apricots" /></div>
                <div>
                  <Label>Country of Origin</Label>
                  <Select value={form.country_of_origin} onValueChange={(v) => set("country_of_origin", v)}>
                    <SelectTrigger><SelectValue placeholder="Select country" /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Uzbekistan">🇺🇿 Uzbekistan</SelectItem>
                      <SelectItem value="Kazakhstan">🇰🇿 Kazakhstan</SelectItem>
                      <SelectItem value="Tajikistan">🇹🇯 Tajikistan</SelectItem>
                      <SelectItem value="Kyrgyzstan">🇰🇬 Kyrgyzstan</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            )}
            {step === 1 && (
              <div className="space-y-4">
                <div><Label>Description</Label><Textarea value={form.description} onChange={(e) => set("description", e.target.value)} placeholder="Describe your product..." rows={4} /></div>
                <div className="grid grid-cols-2 gap-4">
                  <div><Label>MOQ</Label><Input value={form.moq} onChange={(e) => set("moq", e.target.value)} placeholder="e.g. 500" /></div>
                  <div><Label>Unit</Label>
                    <Select value={form.moq_unit} onValueChange={(v) => set("moq_unit", v)}>
                      <SelectTrigger><SelectValue /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="kg">kg</SelectItem>
                        <SelectItem value="ton">ton</SelectItem>
                        <SelectItem value="piece">piece</SelectItem>
                        <SelectItem value="meter">meter</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div><Label>Price From (USD)</Label><Input type="number" value={form.price_from} onChange={(e) => set("price_from", e.target.value)} placeholder="0.00" /></div>
                  <div><Label>Price To (USD)</Label><Input type="number" value={form.price_to} onChange={(e) => set("price_to", e.target.value)} placeholder="0.00" /></div>
                </div>
                <div><Label>Packaging Info</Label><Input value={form.packaging} onChange={(e) => set("packaging", e.target.value)} placeholder="e.g. 10kg cartons" /></div>
                <div><Label>Shelf Life</Label><Input value={form.shelf_life} onChange={(e) => set("shelf_life", e.target.value)} placeholder="e.g. 12 months" /></div>
              </div>
            )}
            {step === 2 && (
              <div>
                <Label className="mb-3 block">Product Photos (max 5)</Label>
                <div className="border-2 border-dashed border-border rounded-lg p-12 text-center cursor-pointer hover:border-primary/40 transition-colors">
                  <Upload size={32} className="mx-auto text-muted-foreground mb-3" />
                  <p className="text-sm text-muted-foreground">Drag and drop images here, or click to browse</p>
                  <p className="text-xs text-muted-foreground mt-1">PNG, JPG up to 5MB each</p>
                </div>
              </div>
            )}
            {step === 3 && (
              <div className="space-y-4">
                <div className="flex items-center justify-between"><Label>Show Email</Label><Switch defaultChecked /></div>
                <div className="flex items-center justify-between"><Label>Show Phone</Label><Switch /></div>
                <div className="flex items-center justify-between"><Label>Show WhatsApp</Label><Switch /></div>
              </div>
            )}

            <div className="flex justify-between mt-8">
              <Button variant="outline" onClick={() => setStep((s) => s - 1)} disabled={step === 0}>
                <ArrowLeft size={14} className="mr-1" /> Previous
              </Button>
              {step < steps.length - 1 ? (
                <Button onClick={() => setStep((s) => s + 1)}>Next <ArrowRight size={14} className="ml-1" /></Button>
              ) : (
                <Button onClick={handlePublish} disabled={saving || !form.name || !form.category}>
                  {saving && <Loader2 size={14} className="mr-1 animate-spin" />}
                  Publish Product
                </Button>
              )}
            </div>
          </CardContent>
        </Card>
      </div>
    </Layout>
  );
};

export default AddProduct;
