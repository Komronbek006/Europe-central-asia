import { useState } from "react";
import { useParams, Link } from "react-router-dom";
import { Layout } from "@/components/layout/Layout";
import { products, suppliers } from "@/data/mock-data";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Separator } from "@/components/ui/separator";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { ShieldCheck, ArrowLeft } from "lucide-react";

const ProductDetail = () => {
  const { slug } = useParams();
  const product = products.find(p => p.slug === slug);

  if (!product) return <Layout><div className="container-narrow py-20 text-center"><h1 className="text-2xl font-bold">Product not found</h1><Link to="/products" className="text-primary mt-4 inline-block">← Back to products</Link></div></Layout>;

  const supplier = suppliers.find(s => s.id === product.supplierId);
  const initials = supplier?.name.split(" ").map(w => w[0]).join("").slice(0, 2) || "??";

  return (
    <Layout>
      <div className="container-narrow py-8">
        <Link to="/products" className="text-sm text-muted-foreground hover:text-foreground inline-flex items-center gap-1 mb-6">
          <ArrowLeft size={14} /> Back to Products
        </Link>

        <div className="grid lg:grid-cols-2 gap-10">
          {/* Image */}
          <div className="aspect-square rounded-lg overflow-hidden bg-muted">
            <img src={product.image} alt={product.name} className="w-full h-full object-cover" />
          </div>

          {/* Info */}
          <div>
            <Badge variant="secondary" className="mb-3">{product.category}</Badge>
            <h1 className="text-3xl font-bold mb-2">{product.name}</h1>
            <p className="text-muted-foreground mb-4">{product.flag} {product.country}</p>

            <div className="text-2xl font-bold text-primary mb-6">
              ${product.priceFrom.toFixed(2)} – ${product.priceTo.toFixed(2)}
              <span className="text-sm font-normal text-muted-foreground ml-1">/ {product.unit}</span>
            </div>

            {/* Key Info Table */}
            <Card className="mb-6">
              <CardContent className="p-0">
                {[
                  ["Origin", `${product.flag} ${product.country}`],
                  ["MOQ", product.moq],
                  ["Packaging", product.packaging],
                  ["Shelf Life", product.shelfLife],
                  ["Delivery Time", product.deliveryTime],
                ].map(([label, value], i) => (
                  <div key={label} className={`flex justify-between py-3 px-4 text-sm ${i > 0 ? "border-t border-border" : ""}`}>
                    <span className="text-muted-foreground">{label}</span>
                    <span className="font-medium">{value}</span>
                  </div>
                ))}
              </CardContent>
            </Card>

            <p className="text-sm text-muted-foreground leading-relaxed mb-6">{product.description}</p>

            {/* Supplier Card */}
            {supplier && (
              <Card className="mb-6">
                <CardContent className="p-4 flex items-center gap-4">
                  <Avatar className="bg-primary/10 text-primary"><AvatarFallback className="bg-primary/10 text-primary font-bold">{initials}</AvatarFallback></Avatar>
                  <div className="flex-1">
                    <div className="flex items-center gap-2">
                      <span className="font-semibold text-sm">{supplier.name}</span>
                      {supplier.verified && <ShieldCheck size={14} className="text-primary" />}
                    </div>
                    <p className="text-xs text-muted-foreground">{supplier.flag} {supplier.country}</p>
                  </div>
                  <Button variant="outline" size="sm" asChild><Link to={`/supplier/${supplier.slug}`}>View</Link></Button>
                </CardContent>
              </Card>
            )}

            <Dialog>
              <DialogTrigger asChild>
                <Button size="lg" className="w-full">Send Inquiry</Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader><DialogTitle>Send Inquiry for {product.name}</DialogTitle></DialogHeader>
                <div className="space-y-4 pt-2">
                  <Input placeholder="Your Name" />
                  <Input placeholder="Company Name" />
                  <Input placeholder="Email" type="email" />
                  <Textarea placeholder="Your message..." rows={4} />
                  <Button className="w-full">Send Inquiry</Button>
                </div>
              </DialogContent>
            </Dialog>
          </div>
        </div>
      </div>
    </Layout>
  );
};

export default ProductDetail;
