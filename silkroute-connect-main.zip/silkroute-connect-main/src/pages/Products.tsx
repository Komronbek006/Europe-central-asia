import { useState } from "react";
import { Layout } from "@/components/layout/Layout";
import { ProductCard } from "@/components/ProductCard";
import { products, categories } from "@/data/mock-data";
import { Input } from "@/components/ui/input";
import { Checkbox } from "@/components/ui/checkbox";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Search, SlidersHorizontal, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";

const countries = [
  { name: "Uzbekistan", flag: "🇺🇿" },
  { name: "Kazakhstan", flag: "🇰🇿" },
  { name: "Tajikistan", flag: "🇹🇯" },
  { name: "Kyrgyzstan", flag: "🇰🇬" },
  { name: "Turkmenistan", flag: "🇹🇲" },
];

function FilterSidebar({ selectedCategories, setSelectedCategories, selectedCountries, setSelectedCountries, verifiedOnly, setVerifiedOnly }: any) {
  const toggleCategory = (slug: string) => {
    setSelectedCategories((prev: string[]) =>
      prev.includes(slug) ? prev.filter((c: string) => c !== slug) : [...prev, slug]
    );
  };
  const toggleCountry = (name: string) => {
    setSelectedCountries((prev: string[]) =>
      prev.includes(name) ? prev.filter((c: string) => c !== name) : [...prev, name]
    );
  };

  return (
    <div className="space-y-6">
      <div>
        <h3 className="font-semibold text-sm mb-3">Category</h3>
        <div className="space-y-2">
          {categories.map(cat => (
            <label key={cat.slug} className="flex items-center gap-2 cursor-pointer">
              <Checkbox checked={selectedCategories.includes(cat.slug)} onCheckedChange={() => toggleCategory(cat.slug)} />
              <span className="text-sm">{cat.icon} {cat.name}</span>
            </label>
          ))}
        </div>
      </div>
      <div>
        <h3 className="font-semibold text-sm mb-3">Country</h3>
        <div className="space-y-2">
          {countries.map(c => (
            <label key={c.name} className="flex items-center gap-2 cursor-pointer">
              <Checkbox checked={selectedCountries.includes(c.name)} onCheckedChange={() => toggleCountry(c.name)} />
              <span className="text-sm">{c.flag} {c.name}</span>
            </label>
          ))}
        </div>
      </div>
      <div className="flex items-center justify-between">
        <Label htmlFor="verified" className="text-sm">Verified Only</Label>
        <Switch id="verified" checked={verifiedOnly} onCheckedChange={setVerifiedOnly} />
      </div>
    </div>
  );
}

const Products = () => {
  const [search, setSearch] = useState("");
  const [sortBy, setSortBy] = useState("newest");
  const [selectedCategories, setSelectedCategories] = useState<string[]>([]);
  const [selectedCountries, setSelectedCountries] = useState<string[]>([]);
  const [verifiedOnly, setVerifiedOnly] = useState(false);

  let filtered = products.filter(p => {
    if (search && !p.name.toLowerCase().includes(search.toLowerCase())) return false;
    if (selectedCategories.length && !selectedCategories.includes(p.category.toLowerCase().replace(" ", "-"))) return false;
    if (selectedCountries.length && !selectedCountries.includes(p.country)) return false;
    if (verifiedOnly && !p.verified) return false;
    return true;
  });

  if (sortBy === "price-low") filtered.sort((a, b) => a.priceFrom - b.priceFrom);
  if (sortBy === "price-high") filtered.sort((a, b) => b.priceFrom - a.priceFrom);

  const filterProps = { selectedCategories, setSelectedCategories, selectedCountries, setSelectedCountries, verifiedOnly, setVerifiedOnly };

  return (
    <Layout>
      <div className="bg-surface border-b border-border">
        <div className="container-narrow py-8">
          <h1 className="text-3xl font-bold mb-2">Products Catalog</h1>
          <p className="text-muted-foreground">Browse verified products from Central Asian suppliers</p>
        </div>
      </div>
      <div className="container-narrow py-8">
        <div className="flex gap-8">
          {/* Desktop sidebar */}
          <aside className="hidden lg:block w-64 flex-shrink-0">
            <FilterSidebar {...filterProps} />
          </aside>

          <div className="flex-1">
            <div className="flex flex-wrap items-center gap-3 mb-6">
              <div className="relative flex-1 min-w-[200px]">
                <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
                <Input placeholder="Search products..." className="pl-9" value={search} onChange={e => setSearch(e.target.value)} />
              </div>
              <Select value={sortBy} onValueChange={setSortBy}>
                <SelectTrigger className="w-[160px]">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="newest">Newest</SelectItem>
                  <SelectItem value="price-low">Price: Low–High</SelectItem>
                  <SelectItem value="price-high">Price: High–Low</SelectItem>
                </SelectContent>
              </Select>
              <Sheet>
                <SheetTrigger asChild>
                  <Button variant="outline" size="icon" className="lg:hidden">
                    <SlidersHorizontal size={16} />
                  </Button>
                </SheetTrigger>
                <SheetContent side="left">
                  <h2 className="font-semibold mb-6">Filters</h2>
                  <FilterSidebar {...filterProps} />
                </SheetContent>
              </Sheet>
            </div>
            <p className="text-sm text-muted-foreground mb-4">{filtered.length} products found</p>
            <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-5">
              {filtered.map(p => <ProductCard key={p.id} {...p} />)}
            </div>
            {filtered.length === 0 && (
              <div className="text-center py-20 text-muted-foreground">
                <p className="text-lg mb-2">No products found</p>
                <p className="text-sm">Try adjusting your filters</p>
              </div>
            )}
          </div>
        </div>
      </div>
    </Layout>
  );
};

export default Products;
