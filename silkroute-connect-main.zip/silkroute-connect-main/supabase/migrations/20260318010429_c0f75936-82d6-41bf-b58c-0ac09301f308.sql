
-- Products table
CREATE TABLE public.products (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  supplier_id uuid NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  name text NOT NULL,
  slug text NOT NULL UNIQUE,
  category text NOT NULL,
  country_of_origin text NOT NULL DEFAULT 'Uzbekistan',
  description text,
  moq integer NOT NULL DEFAULT 100,
  moq_unit text NOT NULL DEFAULT 'kg',
  price_from numeric,
  price_to numeric,
  currency text NOT NULL DEFAULT 'USD',
  packaging text,
  shelf_life text,
  images text[] DEFAULT '{}',
  is_published boolean NOT NULL DEFAULT false,
  view_count integer NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.products ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can view published products" ON public.products
  FOR SELECT USING (is_published = true);

CREATE POLICY "Suppliers can view own products" ON public.products
  FOR SELECT TO authenticated USING (
    supplier_id IN (SELECT id FROM public.profiles WHERE user_id = auth.uid())
  );

CREATE POLICY "Suppliers can insert own products" ON public.products
  FOR INSERT TO authenticated WITH CHECK (
    supplier_id IN (SELECT id FROM public.profiles WHERE user_id = auth.uid() AND type = 'supplier')
  );

CREATE POLICY "Suppliers can update own products" ON public.products
  FOR UPDATE TO authenticated USING (
    supplier_id IN (SELECT id FROM public.profiles WHERE user_id = auth.uid())
  );

CREATE POLICY "Suppliers can delete own products" ON public.products
  FOR DELETE TO authenticated USING (
    supplier_id IN (SELECT id FROM public.profiles WHERE user_id = auth.uid())
  );

CREATE TRIGGER update_products_updated_at BEFORE UPDATE ON public.products
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- Inquiries table
CREATE TABLE public.inquiries (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  buyer_id uuid NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  supplier_id uuid NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  product_id uuid REFERENCES public.products(id) ON DELETE SET NULL,
  message text NOT NULL,
  status text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'replied', 'closed')),
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.inquiries ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Buyers can view own inquiries" ON public.inquiries
  FOR SELECT TO authenticated USING (
    buyer_id IN (SELECT id FROM public.profiles WHERE user_id = auth.uid())
  );

CREATE POLICY "Suppliers can view received inquiries" ON public.inquiries
  FOR SELECT TO authenticated USING (
    supplier_id IN (SELECT id FROM public.profiles WHERE user_id = auth.uid())
  );

CREATE POLICY "Buyers can create inquiries" ON public.inquiries
  FOR INSERT TO authenticated WITH CHECK (
    buyer_id IN (SELECT id FROM public.profiles WHERE user_id = auth.uid() AND type = 'buyer')
  );

CREATE POLICY "Suppliers can update inquiry status" ON public.inquiries
  FOR UPDATE TO authenticated USING (
    supplier_id IN (SELECT id FROM public.profiles WHERE user_id = auth.uid())
  );

-- Saved suppliers table
CREATE TABLE public.saved_suppliers (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  buyer_id uuid NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  supplier_id uuid NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE(buyer_id, supplier_id)
);

ALTER TABLE public.saved_suppliers ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Buyers can view own saved suppliers" ON public.saved_suppliers
  FOR SELECT TO authenticated USING (
    buyer_id IN (SELECT id FROM public.profiles WHERE user_id = auth.uid())
  );

CREATE POLICY "Buyers can save suppliers" ON public.saved_suppliers
  FOR INSERT TO authenticated WITH CHECK (
    buyer_id IN (SELECT id FROM public.profiles WHERE user_id = auth.uid())
  );

CREATE POLICY "Buyers can unsave suppliers" ON public.saved_suppliers
  FOR DELETE TO authenticated USING (
    buyer_id IN (SELECT id FROM public.profiles WHERE user_id = auth.uid())
  );

-- Blog posts table
CREATE TABLE public.blog_posts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  slug text NOT NULL UNIQUE,
  category text,
  content text,
  excerpt text,
  cover_image text,
  published_at timestamptz DEFAULT now(),
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.blog_posts ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can view blog posts" ON public.blog_posts
  FOR SELECT USING (true);
